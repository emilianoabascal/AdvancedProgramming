/*
	Emiliano Abascal Gurria A01023234
	21/10/2018
*/

#ifndef BANK_CLIENT_H
#define BANK_CLIENT_H
#define BUFFER_SIZE 1024
void usage(char * program);
void bankOperations(int connection_fd);
#endif
